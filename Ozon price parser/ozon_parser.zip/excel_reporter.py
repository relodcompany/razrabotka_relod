"""
Создание Excel отчетов с форматированием
"""
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.formatting.rule import CellIsRule
from datetime import datetime
import logging
from config import OUTPUT_DIR, CRITICAL_PRICE_DIFF_PERCENT

logging.basicConfig(level=logging.INFO)

class ExcelReporter:
    """Класс для создания Excel отчетов"""
    
    def __init__(self):
        self.critical_diff = CRITICAL_PRICE_DIFF_PERCENT
        
        # Цвета для форматирования
        self.red_fill = PatternFill(start_color="FFFF0000", end_color="FFFF0000", fill_type="solid")
        self.yellow_fill = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")
        self.grey_fill = PatternFill(start_color="FFD3D3D3", end_color="FFD3D3D3", fill_type="solid")
        
        # Шрифты
        self.header_font = Font(bold=True, size=12)
        self.link_font = Font(color="FF0000FF", underline="single")
    
    def create_report(self, results, filename=None):
        """
        Создает Excel файл с результатами парсинга
        
        Args:
            results: Список словарей с результатами
            filename: Имя файла (если None, генерируется автоматически)
            
        Returns:
            str: Путь к созданному файлу
        """
        if not filename:
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            filename = f"{OUTPUT_DIR}/competitive_prices_{timestamp}.xlsx"
        
        wb = Workbook()
        
        # Создаем листы
        ws_main = wb.active
        ws_main.title = "Результаты"
        ws_attention = wb.create_sheet("Требует внимания")
        ws_history = wb.create_sheet("История")
        
        # Заполняем основной лист
        self._fill_main_sheet(ws_main, results)
        
        # Заполняем лист "Требует внимания"
        critical_items = [r for r in results if self._is_critical(r)]
        self._fill_attention_sheet(ws_attention, critical_items)
        
        # Форматируем листы
        self._format_sheet(ws_main)
        self._format_sheet(ws_attention)
        
        # Сохраняем файл
        wb.save(filename)
        logging.info(f"Excel отчет сохранен: {filename}")
        
        return filename
    
    def _fill_main_sheet(self, ws, results):
        """Заполняет основной лист данными"""
        # Заголовки
        headers = [
            "ISBN", "Название", "Автор", "Издательство",
            "Наша цена (руб.)", "Цена конкурента (руб.)",
            "Разница (руб.)", "Разница (%)",
            "Статус", "Ссылка", "Продавец", "Рейтинг", "Дата парсинга"
        ]
        
        ws.append(headers)
        
        # Применяем стиль к заголовкам
        for cell in ws[1]:
            cell.font = self.header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # Заполняем данными
        for result in results:
            row = [
                result.get('isbn', ''),
                result.get('title', ''),
                result.get('author', ''),
                result.get('publisher', ''),
                result.get('our_price', ''),
                result.get('competitor_price', ''),
                result.get('price_diff_rub', ''),
                result.get('price_diff_percent', ''),
                result.get('status', ''),
                result.get('url', ''),
                result.get('seller', ''),
                result.get('rating', ''),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ]
            
            ws.append(row)
            
            # Применяем форматирование к последней добавленной строке
            row_num = ws.max_row
            self._apply_row_formatting(ws, row_num, result)
    
    def _fill_attention_sheet(self, ws, critical_items):
        """Заполняет лист 'Требует внимания'"""
        # Те же заголовки
        headers = [
            "ISBN", "Название", "Автор", "Издательство",
            "Наша цена (руб.)", "Цена конкурента (руб.)",
            "Разница (руб.)", "Разница (%)",
            "Статус", "Ссылка", "Продавец", "Рейтинг", "Дата парсинга"
        ]
        
        ws.append(headers)
        
        # Применяем стиль к заголовкам
        for cell in ws[1]:
            cell.font = self.header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # Сортируем по разнице в цене (от большей к меньшей)
        sorted_items = sorted(
            critical_items,
            key=lambda x: abs(x.get('price_diff_percent', 0) or 0),
            reverse=True
        )
        
        # Заполняем данными
        for result in sorted_items:
            row = [
                result.get('isbn', ''),
                result.get('title', ''),
                result.get('author', ''),
                result.get('publisher', ''),
                result.get('our_price', ''),
                result.get('competitor_price', ''),
                result.get('price_diff_rub', ''),
                result.get('price_diff_percent', ''),
                result.get('status', ''),
                result.get('url', ''),
                result.get('seller', ''),
                result.get('rating', ''),
                datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ]
            
            ws.append(row)
            
            # Применяем форматирование
            row_num = ws.max_row
            self._apply_row_formatting(ws, row_num, result)
    
    def _apply_row_formatting(self, ws, row_num, result):
        """Применяет цветовое форматирование к строке"""
        status = result.get('status', '')
        price_diff_percent = result.get('price_diff_percent')
        
        # Красное выделение: разница > critical_diff%
        if price_diff_percent and abs(price_diff_percent) > self.critical_diff:
            for col in range(1, 14):
                ws.cell(row=row_num, column=col).fill = self.red_fill
        
        # Желтое выделение: ошибка парсинга
        elif status == 'Ошибка парсинга':
            for col in range(1, 14):
                ws.cell(row=row_num, column=col).fill = self.yellow_fill
        
        # Серое выделение: только цена с картой
        elif status == 'Только цена с картой':
            for col in range(1, 14):
                ws.cell(row=row_num, column=col).fill = self.grey_fill
        
        # Форматирование ссылки (синий цвет)
        url_cell = ws.cell(row=row_num, column=10)
        if result.get('url'):
            url_cell.hyperlink = result['url']
            url_cell.font = self.link_font
    
    def _is_critical(self, result):
        """Проверяет, является ли товар критическим"""
        status = result.get('status', '')
        price_diff_percent = result.get('price_diff_percent')
        
        # Критические условия:
        # 1. Разница в цене > critical_diff%
        # 2. Статус "Только цена с картой"
        
        if status == 'Только цена с картой':
            return True
        
        if price_diff_percent and abs(price_diff_percent) > self.critical_diff:
            return True
        
        return False
    
    def _format_sheet(self, ws):
        """Применяет общее форматирование к листу"""
        # Автоматическая ширина колонок
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Включаем автофильтр
        ws.auto_filter.ref = ws.dimensions
        
        # Замораживаем первую строку (шапку)
        ws.freeze_panes = 'A2'


# Пример использования
if __name__ == "__main__":
    # Тестовые данные
    test_results = [
        {
            'isbn': '9785171508180',
            'title': 'Гарри Поттер и философский камень',
            'author': 'Дж. К. Роулинг',
            'publisher': 'АСТ',
            'our_price': 500,
            'competitor_price': 380,
            'price_diff_rub': -120,
            'price_diff_percent': -24,
            'status': 'Найдено',
            'url': 'https://www.ozon.ru/product/123456',
            'seller': 'Книжный мир',
            'rating': '4.8'
        },
        {
            'isbn': '9785171202477',
            'title': 'Тестовая книга',
            'author': 'Тестовый автор',
            'publisher': 'Тестовое издательство',
            'our_price': 600,
            'competitor_price': None,
            'price_diff_rub': None,
            'price_diff_percent': None,
            'status': 'Не найдено',
            'url': '',
            'seller': '',
            'rating': ''
        }
    ]
    
    reporter = ExcelReporter()
    filename = reporter.create_report(test_results)
    print(f"Отчет создан: {filename}")