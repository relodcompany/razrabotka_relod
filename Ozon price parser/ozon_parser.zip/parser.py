"""
Парсинг цен конкурентов на Ozon
Поиск товаров по ISBN и названию, извлечение серых цен
"""
import requests
from bs4 import BeautifulSoup
import time
import logging
import random
from config import PROXY_SOCKS5, DELAY_BETWEEN_REQUESTS, PROXIES_FILE
import os

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/parser.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

class OzonParser:
    """Класс для парсинга цен конкурентов на Ozon"""
    
    def __init__(self):
        self.base_url = "https://www.ozon.ru"
        self.delay = DELAY_BETWEEN_REQUESTS
        self.proxies_list = self._load_proxies()
        self.current_proxy_index = 0
        
        # User-Agent для имитации браузера
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        ]
    
    def _load_proxies(self):
        """Загружает список прокси из файла"""
        proxies = []
        
        if os.path.exists(PROXIES_FILE):
            try:
                with open(PROXIES_FILE, 'r', encoding='utf-8') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            proxies.append(line)
                logging.info(f"Загружено {len(proxies)} прокси из файла")
            except Exception as e:
                logging.error(f"Ошибка загрузки прокси: {e}")
        
        # Если нет прокси в файле, используем из .env
        if not proxies and PROXY_SOCKS5:
            proxies.append(PROXY_SOCKS5)
        
        return proxies
    
    def _get_next_proxy(self):
        """Возвращает следующий прокси из списка (ротация)"""
        if not self.proxies_list:
            return None
        
        proxy = self.proxies_list[self.current_proxy_index]
        self.current_proxy_index = (self.current_proxy_index + 1) % len(self.proxies_list)
        
        return {
            'http': proxy,
            'https': proxy
        }
    
    def _get_headers(self):
        """Возвращает заголовки с случайным User-Agent"""
        return {
            'User-Agent': random.choice(self.user_agents),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
    
    def search_by_isbn(self, isbn, our_product_id):
        """
        Ищет товар на Ozon по ISBN
        
        Args:
            isbn: ISBN книги
            our_product_id: ID нашего товара (для исключения из результатов)
            
        Returns:
            dict: Информация о найденном товаре или None
        """
        if not isbn:
            return None
        
        search_url = f"{self.base_url}/search/?text={isbn}"
        
        try:
            logging.info(f"Поиск по ISBN: {isbn}")
            
            proxies = self._get_next_proxy()
            headers = self._get_headers()
            
            response = requests.get(
                search_url,
                headers=headers,
                proxies=proxies,
                timeout=20
            )
            
            # Задержка между запросами
            time.sleep(self.delay)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Ищем карточки товаров (обновленная структура Ozon)
                # ВНИМАНИЕ: Структура HTML может меняться, проверьте актуальность селекторов
                product_cards = soup.find_all('div', {'data-widget': 'searchResultsV2'})
                
                if not product_cards:
                    logging.warning(f"Товары не найдены по ISBN: {isbn}")
                    return None
                
                # Парсим первую карточку товара (предполагая, что это наиболее релевантный результат)
                # В реальности нужно проверить, что это не наш товар
                result = self._parse_product_card(soup, our_product_id)
                
                return result
            else:
                logging.error(f"Ошибка запроса: {response.status_code}")
                return None
                
        except Exception as e:
            logging.error(f"Ошибка поиска по ISBN {isbn}: {e}")
            return None
    
    def search_by_title(self, title, author, publisher, our_product_id):
        """
        Ищет товар на Ozon по названию с проверкой автора и издательства
        
        Args:
            title: Название книги
            author: Автор (для валидации)
            publisher: Издательство (для валидации)
            our_product_id: ID нашего товара
            
        Returns:
            dict: Информация о найденном товаре или None
        """
        if not title:
            return None
        
        # Формируем поисковый запрос
        search_query = f"{title} {author}" if author else title
        search_url = f"{self.base_url}/search/?text={requests.utils.quote(search_query)}"
        
        try:
            logging.info(f"Поиск по названию: {search_query}")
            
            proxies = self._get_next_proxy()
            headers = self._get_headers()
            
            response = requests.get(
                search_url,
                headers=headers,
                proxies=proxies,
                timeout=20
            )
            
            time.sleep(self.delay)
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                result = self._parse_product_card(soup, our_product_id, author, publisher)
                return result
            else:
                logging.error(f"Ошибка запроса: {response.status_code}")
                return None
                
        except Exception as e:
            logging.error(f"Ошибка поиска по названию {title}: {e}")
            return None
    
    def _parse_product_card(self, soup, our_product_id, author=None, publisher=None):
        """
        Парсит карточку товара и извлекает информацию
        
        ВАЖНО: Структура HTML Ozon часто меняется!
        Этот код может потребовать обновления селекторов.
        """
        try:
            # Ищем серую цену (цену без карты)
            # Селекторы могут отличаться, нужно проверять актуальную структуру
            price_element = soup.find('span', {'data-widget': 'webPrice'})
            
            if not price_element:
                # Альтернативный поиск цены
                price_element = soup.find('span', class_='tsBody500Medium')
            
            if not price_element:
                logging.warning("Не найдена цена на странице")
                return None
            
            # Извлекаем цену (убираем символы валюты и пробелы)
            price_text = price_element.get_text().strip()
            price = float(''.join(filter(str.isdigit, price_text)))
            
            # Извлекаем название товара
            title_element = soup.find('span', class_='tsHeadline550Medium')
            title = title_element.get_text().strip() if title_element else ""
            
            # Извлекаем ссылку на товар
            link_element = soup.find('a', {'data-widget': 'searchResultsItem'})
            product_url = f"{self.base_url}{link_element['href']}" if link_element and link_element.get('href') else ""
            
            # Извлекаем продавца
            seller_element = soup.find('span', class_='tsBodyControl400Small')
            seller = seller_element.get_text().strip() if seller_element else ""
            
            # Валидация по автору и издательству (если указаны)
            if author or publisher:
                # Проверяем совпадение (упрощенная проверка)
                page_text = soup.get_text().lower()
                
                if author and author.lower() not in page_text:
                    logging.warning(f"Автор не совпадает: {author}")
                    return {
                        'status': 'Несовпадение данных',
                        'price': None,
                        'url': product_url,
                        'seller': seller,
                        'title': title
                    }
                
                if publisher and publisher.lower() not in page_text:
                    logging.warning(f"Издательство не совпадает: {publisher}")
                    return {
                        'status': 'Несовпадение данных',
                        'price': None,
                        'url': product_url,
                        'seller': seller,
                        'title': title
                    }
            
            return {
                'status': 'Найдено',
                'price': price,
                'url': product_url,
                'seller': seller,
                'title': title
            }
            
        except Exception as e:
            logging.error(f"Ошибка парсинга карточки товара: {e}")
            return None
    
    def parse_product(self, product_data):
        """
        Основная функция парсинга одного товара
        
        Args:
            product_data: Словарь с данными товара (из Ozon API)
            
        Returns:
            dict: Результат парсинга
        """
        isbn = product_data.get('isbn', '')
        title = product_data.get('name', '')
        author = product_data.get('author', '')
        publisher = product_data.get('publisher', '')
        our_product_id = product_data.get('product_id', '')
        our_price = product_data.get('price', '')
        
        result = {
            'isbn': isbn,
            'title': title,
            'author': author,
            'publisher': publisher,
            'our_price': our_price,
            'competitor_price': None,
            'price_diff_rub': None,
            'price_diff_percent': None,
            'status': 'Не найдено',
            'url': '',
            'seller': '',
            'rating': ''
        }
        
        # Шаг 1: Поиск по ISBN (приоритетный)
        if isbn:
            competitor_data = self.search_by_isbn(isbn, our_product_id)
            if competitor_data and competitor_data.get('price'):
                result.update(competitor_data)
                result['competitor_price'] = competitor_data['price']
                
                # Рассчитываем разницу в цене
                try:
                    our_price_float = float(our_price) if our_price else 0
                    comp_price = float(competitor_data['price'])
                    
                    if our_price_float > 0:
                        result['price_diff_rub'] = comp_price - our_price_float
                        result['price_diff_percent'] = ((comp_price - our_price_float) / our_price_float) * 100
                except:
                    pass
                
                return result
        
        # Шаг 2: Поиск по названию (если не нашли по ISBN)
        if title:
            competitor_data = self.search_by_title(title, author, publisher, our_product_id)
            if competitor_data:
                result.update(competitor_data)
                if competitor_data.get('price'):
                    result['competitor_price'] = competitor_data['price']
                    
                    # Рассчитываем разницу в цене
                    try:
                        our_price_float = float(our_price) if our_price else 0
                        comp_price = float(competitor_data['price'])
                        
                        if our_price_float > 0:
                            result['price_diff_rub'] = comp_price - our_price_float
                            result['price_diff_percent'] = ((comp_price - our_price_float) / our_price_float) * 100
                    except:
                        pass
                
                return result
        
        # Если ничего не нашли
        result['status'] = 'Не найдено'
        logging.warning(f"Товар не найден: {title}")
        
        return result


# Пример использования
if __name__ == "__main__":
    parser = OzonParser()
    
    # Тестовый товар
    test_product = {
        'isbn': '9785171508180',
        'name': 'Гарри Поттер и философский камень',
        'author': 'Дж. К. Роулинг',
        'publisher': 'АСТ',
        'product_id': '123456',
        'price': '500'
    }
    
    result = parser.parse_product(test_product)
    
    print("\nРезультат парсинга:")
    print(f"Статус: {result['status']}")
    print(f"Наша цена: {result['our_price']} руб.")
    print(f"Цена конкурента: {result['competitor_price']} руб.")
    print(f"Разница: {result['price_diff_rub']} руб. ({result['price_diff_percent']:.1f}%)")
    print(f"Ссылка: {result['url']}")