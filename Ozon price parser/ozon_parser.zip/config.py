"""
Конфигурация парсера Ozon
Загрузка переменных окружения из .env файла
"""
import os
from dotenv import load_dotenv

# Загружаем переменные из .env
load_dotenv()

# API ключи Ozon
OZON_CLIENT_ID = os.getenv("OZON_CLIENT_ID")
OZON_API_KEY = os.getenv("OZON_API_KEY")

# Прокси настройки
PROXY_SOCKS5 = os.getenv("PROXY_SOCKS5")

# Email уведомления
EMAIL_RECIPIENT = os.getenv("EMAIL_RECIPIENT", "")

# Telegram уведомления
TELEGRAM_ENABLED = os.getenv("TELEGRAM_ENABLED", "false").lower() == "true"
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# Настройки парсинга
SCHEDULE_INTERVAL_DAYS = int(os.getenv("SCHEDULE_INTERVAL_DAYS", "14"))
DELAY_BETWEEN_REQUESTS = int(os.getenv("DELAY_BETWEEN_REQUESTS", "1"))
CRITICAL_PRICE_DIFF_PERCENT = int(os.getenv("CRITICAL_PRICE_DIFF_PERCENT", "20"))

# Пути к папкам
OUTPUT_DIR = "output"
HISTORY_DIR = "history"
LOGS_DIR = "logs"
PROXIES_FILE = "proxies.txt"

# Создаём папки если их нет
for directory in [OUTPUT_DIR, HISTORY_DIR, LOGS_DIR]:
    if not os.path.exists(directory):
        os.makedirs(directory)

# Проверка обязательных параметров
if not OZON_CLIENT_ID or not OZON_API_KEY:
    print("⚠️ ОШИБКА: Не указаны OZON_CLIENT_ID или OZON_API_KEY в файле .env")
    print("Получите их на: seller.ozon.ru -> Настройки -> API ключи")
    
if not PROXY_SOCKS5:
    print("⚠️ ПРЕДУПРЕЖДЕНИЕ: Не указан PROXY_SOCKS5 в файле .env")
    print("Рекомендуется использовать прокси для избежания бана")