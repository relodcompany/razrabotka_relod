"""
Работа с Ozon Seller API
Получение списка товаров и цен из вашего магазина
"""
import requests
import logging
from config import OZON_CLIENT_ID, OZON_API_KEY, PROXY_SOCKS5

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/ozon_api.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

class OzonAPI:
    """Класс для работы с Ozon Seller API"""
    
    def __init__(self):
        self.base_url = "https://api-seller.ozon.ru"
        self.headers = {
            'Client-Id': str(OZON_CLIENT_ID),
            'Api-Key': OZON_API_KEY,
            'Content-Type': 'application/json'
        }
        
        # Настройка прокси
        self.proxies = None
        if PROXY_SOCKS5:
            self.proxies = {
                'http': PROXY_SOCKS5,
                'https': PROXY_SOCKS5
            }
            logging.info(f"Используется прокси для API запросов")
    
    def get_products_list(self, limit=1000):
        """
        Получает список всех товаров из вашего магазина на Ozon
        
        Args:
            limit: Максимальное количество товаров за один запрос (макс 1000)
            
        Returns:
            list: Список товаров с данными
        """
        url = f"{self.base_url}/v2/product/list"
        
        all_products = []
        last_id = ""
        
        try:
            while True:
                payload = {
                    "filter": {
                        "visibility": "ALL"
                    },
                    "last_id": last_id,
                    "limit": limit
                }
                
                logging.info(f"Запрос списка товаров (last_id: {last_id})...")
                
                response = requests.post(
                    url, 
                    json=payload, 
                    headers=self.headers, 
                    proxies=self.proxies,
                    timeout=30
                )
                
                if response.status_code == 200:
                    data = response.json()
                    items = data.get('result', {}).get('items', [])
                    
                    if not items:
                        break
                    
                    all_products.extend(items)
                    logging.info(f"Получено товаров: {len(items)}, всего: {len(all_products)}")
                    
                    # Проверяем есть ли ещё товары
                    last_id = data.get('result', {}).get('last_id', "")
                    if not last_id:
                        break
                else:
                    logging.error(f"Ошибка API: {response.status_code} - {response.text}")
                    break
                    
        except Exception as e:
            logging.error(f"Ошибка при получении списка товаров: {e}")
        
        logging.info(f"Всего получено товаров: {len(all_products)}")
        return all_products
    
    def get_product_info(self, product_ids):
        """
        Получает детальную информацию о товарах (включая цены)
        
        Args:
            product_ids: Список ID товаров (до 1000 за раз)
            
        Returns:
            list: Список с детальной информацией о товарах
        """
        url = f"{self.base_url}/v2/product/info/list"
        
        # Разбиваем на части по 1000 товаров
        chunk_size = 1000
        all_info = []
        
        for i in range(0, len(product_ids), chunk_size):
            chunk = product_ids[i:i + chunk_size]
            
            payload = {
                "product_id": chunk
            }
            
            try:
                logging.info(f"Запрос информации о {len(chunk)} товарах...")
                
                response = requests.post(
                    url,
                    json=payload,
                    headers=self.headers,
                    proxies=self.proxies,
                    timeout=30
                )
                
                if response.status_code == 200:
                    data = response.json()
                    items = data.get('result', {}).get('items', [])
                    all_info.extend(items)
                    logging.info(f"Получена информация о {len(items)} товарах")
                else:
                    logging.error(f"Ошибка API: {response.status_code} - {response.text}")
                    
            except Exception as e:
                logging.error(f"Ошибка при получении информации о товарах: {e}")
        
        return all_info
    
    def get_all_products_with_prices(self):
        """
        Получает все товары со всей информацией (включая цены, ISBN и т.д.)
        
        Returns:
            list: Список словарей с информацией о каждом товаре
        """
        logging.info("Начинаем получение всех товаров из магазина...")
        
        # Шаг 1: Получаем список товаров
        products = self.get_products_list()
        
        if not products:
            logging.warning("Не удалось получить список товаров")
            return []
        
        # Шаг 2: Получаем детальную информацию
        product_ids = [item['product_id'] for item in products]
        products_info = self.get_product_info(product_ids)
        
        # Шаг 3: Форматируем данные для удобства
        formatted_products = []
        
        for product in products_info:
            # Ищем ISBN в атрибутах
            isbn = ""
            attributes = product.get('attributes', [])
            for attr in attributes:
                if attr.get('attribute_id') == 85 or 'ISBN' in attr.get('attribute_name', '').upper():
                    values = attr.get('values', [])
                    if values:
                        isbn = values[0].get('value', '')
                        break
            
            formatted_product = {
                'product_id': product.get('id'),
                'offer_id': product.get('offer_id', ''),
                'name': product.get('name', ''),
                'price': product.get('price', ''),
                'old_price': product.get('old_price', ''),
                'currency_code': product.get('currency_code', 'RUB'),
                'isbn': isbn,
                'barcode': product.get('barcode', ''),
                'description': product.get('description', ''),
                'category_id': product.get('category_id', ''),
                # Извлекаем автора и издательство из атрибутов
                'author': self._extract_attribute(attributes, 'Автор'),
                'publisher': self._extract_attribute(attributes, 'Издательство')
            }
            
            formatted_products.append(formatted_product)
        
        logging.info(f"Успешно получено {len(formatted_products)} товаров с полной информацией")
        return formatted_products
    
    def _extract_attribute(self, attributes, attribute_name):
        """Вспомогательная функция для извлечения значения атрибута"""
        for attr in attributes:
            if attribute_name.lower() in attr.get('attribute_name', '').lower():
                values = attr.get('values', [])
                if values:
                    return values[0].get('value', '')
        return ''


# Пример использования
if __name__ == "__main__":
    api = OzonAPI()
    products = api.get_all_products_with_prices()
    
    print(f"\nПолучено товаров: {len(products)}")
    
    if products:
        print("\nПример первого товара:")
        print(f"Название: {products[0]['name']}")
        print(f"ISBN: {products[0]['isbn']}")
        print(f"Цена: {products[0]['price']} {products[0]['currency_code']}")
        print(f"Автор: {products[0]['author']}")
        print(f"Издательство: {products[0]['publisher']}")