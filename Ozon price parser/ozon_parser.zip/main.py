"""
Главный модуль парсера цен конкурентов на Ozon
Объединяет все компоненты и управляет процессом парсинга
"""
import logging
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
import time

# Импортируем наши модули
from config import SCHEDULE_INTERVAL_DAYS
from ozon_api import OzonAPI
from parser import OzonParser
from excel_reporter import ExcelReporter
from history_manager import HistoryManager
from notifications import NotificationManager

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/main.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

class OzonPriceParser:
    """Главный класс парсера"""
    
    def __init__(self):
        self.ozon_api = OzonAPI()
        self.parser = OzonParser()
        self.reporter = ExcelReporter()
        self.history = HistoryManager()
        self.notifier = NotificationManager()
    
    def run_parsing(self):
        """Запускает полный цикл парсинга"""
        try:
            logging.info("="*60)
            logging.info("НАЧАЛО ПАРСИНГА ЦЕН КОНКУРЕНТОВ НА OZON")
            logging.info("="*60)
            
            start_time = datetime.now()
            
            # Шаг 1: Получаем наши товары из Ozon API
            logging.info("\n📥 Шаг 1: Получение товаров из магазина...")
            our_products = self.ozon_api.get_all_products_with_prices()
            
            if not our_products:
                error_msg = "Не удалось получить товары из Ozon API"
                logging.error(error_msg)
                self.notifier.send_error_notification(error_msg)
                return
            
            logging.info(f"✅ Получено товаров: {len(our_products)}")
            
            # Шаг 2: Парсим цены конкурентов
            logging.info(f"\n🔍 Шаг 2: Парсинг цен конкурентов...")
            logging.info(f"Это может занять продолжительное время...")
            
            results = []
            stats = {
                'total': len(our_products),
                'found': 0,
                'not_found': 0,
                'errors': 0,
                'only_card_price': 0,
                'data_mismatch': 0
            }
            
            for i, product in enumerate(our_products, 1):
                logging.info(f"\n[{i}/{len(our_products)}] Обработка: {product.get('name', 'Без названия')[:50]}...")
                
                try:
                    result = self.parser.parse_product(product)
                    results.append(result)
                    
                    # Обновляем статистику
                    status = result.get('status', '')
                    if status == 'Найдено':
                        stats['found'] += 1
                    elif status == 'Не найдено':
                        stats['not_found'] += 1
                    elif status == 'Ошибка парсинга':
                        stats['errors'] += 1
                    elif status == 'Только цена с картой':
                        stats['only_card_price'] += 1
                    elif status == 'Несовпадение данных':
                        stats['data_mismatch'] += 1
                    
                    # Логируем результат
                    if result.get('competitor_price'):
                        diff = result.get('price_diff_percent', 0)
                        logging.info(f"   ✅ Найдено! Разница: {diff:.1f}%")
                    else:
                        logging.info(f"   ⚠️ {status}")
                    
                except Exception as e:
                    logging.error(f"   ❌ Ошибка обработки товара: {e}")
                    stats['errors'] += 1
            
            # Шаг 3: Создаем Excel отчет
            logging.info(f"\n📊 Шаг 3: Создание Excel отчета...")
            excel_file = self.reporter.create_report(results)
            logging.info(f"✅ Отчет создан: {excel_file}")
            
            # Шаг 4: Сохраняем в историю
            logging.info(f"\n💾 Шаг 4: Сохранение в историю...")
            self.history.save_to_history(excel_file)
            
            # Шаг 5: Отправляем уведомления
            logging.info(f"\n📧 Шаг 5: Отправка уведомлений...")
            
            # Находим критические товары
            critical_items = [r for r in results if self._is_critical(r)]
            
            # Добавляем дату в статистику
            stats['date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # Отправляем уведомление
            self.notifier.send_completion_notification(stats, critical_items, excel_file)
            
            # Итоговая статистика
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            logging.info("\n" + "="*60)
            logging.info("ПАРСИНГ ЗАВЕРШЕН!")
            logging.info("="*60)
            logging.info(f"\n📈 ИТОГОВАЯ СТАТИСТИКА:")
            logging.info(f"   • Всего товаров: {stats['total']}")
            logging.info(f"   • Найдено конкурентов: {stats['found']}")
            logging.info(f"   • Не найдено: {stats['not_found']}")
            logging.info(f"   • Ошибок парсинга: {stats['errors']}")
            logging.info(f"   • Только цена с картой: {stats['only_card_price']}")
            logging.info(f"   • Несовпадение данных: {stats['data_mismatch']}")
            logging.info(f"   • Критических позиций: {len(critical_items)}")
            logging.info(f"\n⏱️ Время выполнения: {duration:.0f} сек ({duration/60:.1f} мин)")
            logging.info(f"\n📁 Отчет сохранен: {excel_file}")
            logging.info("="*60 + "\n")
            
        except Exception as e:
            error_msg = f"Критическая ошибка при парсинге: {e}"
            logging.error(error_msg, exc_info=True)
            self.notifier.send_error_notification(error_msg)
    
    def _is_critical(self, result):
        """Проверяет, является ли товар критическим"""
        from config import CRITICAL_PRICE_DIFF_PERCENT
        
        status = result.get('status', '')
        price_diff_percent = result.get('price_diff_percent')
        
        if status == 'Только цена с картой':
            return True
        
        if price_diff_percent and abs(price_diff_percent) > CRITICAL_PRICE_DIFF_PERCENT:
            return True
        
        return False


def main():
    """Главная функция"""
    print("\n" + "="*60)
    print("  ПАРСЕР ЦЕН КОНКУРЕНТОВ НА OZON")
    print("  Для книжного магазина")
    print("="*60 + "\n")
    
    parser = OzonPriceParser()
    
    # Создаем планировщик
    scheduler = BackgroundScheduler()
    
    # Добавляем задачу по расписанию (каждые N дней)
    scheduler.add_job(
        parser.run_parsing,
        'interval',
        days=SCHEDULE_INTERVAL_DAYS,
        id='ozon_parsing_job',
        name='Парсинг цен Ozon'
    )
    
    print(f"⏰ Автоматический парсинг настроен: каждые {SCHEDULE_INTERVAL_DAYS} дней\n")
    print("Выберите действие:")
    print("1. Запустить парсинг сейчас (вручную)")
    print("2. Запустить по расписанию (фоновый режим)")
    print("3. Выход")
    
    choice = input("\nВаш выбор (1-3): ").strip()
    
    if choice == '1':
        # Запуск вручную
        print("\n🚀 Запуск парсинга вручную...\n")
        parser.run_parsing()
        print("\n✅ Парсинг завершен!")
        
    elif choice == '2':
        # Запуск по расписанию
        scheduler.start()
        print(f"\n✅ Планировщик запущен!")
        print(f"📅 Следующий запуск через {SCHEDULE_INTERVAL_DAYS} дней")
        print("\n💡 Для ручного запуска нажмите Ctrl+C и перезапустите программу с выбором '1'")
        print("💡 Для остановки планировщика нажмите Ctrl+C\n")
        
        try:
            # Держим программу запущенной
            while True:
                time.sleep(1)
        except (KeyboardInterrupt, SystemExit):
            scheduler.shutdown()
            print("\n\n⛔ Планировщик остановлен")
    
    else:
        print("\n👋 До свидания!")


if __name__ == "__main__":
    main()